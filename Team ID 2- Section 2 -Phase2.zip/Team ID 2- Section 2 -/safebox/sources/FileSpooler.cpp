#include <FileSpooler.h>
#include<cmath> 
Block * FileSpooler::getBlockLockFree()
{
    Block * b = new Block (block_size);
    if (b->load(f)) return b;
    else {
        delete (b);
        return NULL;
    }
}


FileSpooler::FileSpooler(const char * p_file_name, uint16_t p_block_size, bool truncate)
{
    fsize = 0;
    if ( truncate )
        f.open(p_file_name,ios::in|ios::out|ios::trunc);
    else f.open(p_file_name,ios::in|ios::out);
    if ( f.is_open())
    {
        long cur = f.tellg ();
        f.seekg(0,f.end);
        fsize = f.tellg ();
        f.seekg(cur,f.beg);
    }
    block_size = p_block_size;
}
 Block * FileSpooler::operator [] (long index)
 {
    mtx.lock();
    if ( index*block_size >= fsize) 
    {
        mtx.unlock();
        return NULL;
    }
    long cur = f.tellg ();
    f.seekg(index*block_size,f.beg);
    Block * b  = getBlockLockFree();
    f.seekg(cur,f.beg);
    mtx.unlock();
    return b;
 }
long FileSpooler::getBlockCount () 
{
// ciel fsize/blocksize
    if (fsize%block_size ==0 )
	 return fsize/block_size;
else return (fsize/block_size+1); 
// cout << "hhhhhh";
}


Block * FileSpooler::getNextBlock()
{
    mtx.lock(); 
    Block * b  = getBlockLockFree();
    return b;
    mtx.unlock ();
}
void FileSpooler::appendBlock (Block * b)
{
    mtx.lock();
    b->store(f);
    mtx.unlock();
}
void FileSpooler::writeBlockAt(Block *b,long block_index) 
{
//lock to prevent multithreading from writting at the same position :: atomic
mtx.lock();
//seek pointer at the desired location and store
long location = block_size*block_index;
f.seekp(location,std::ios_base::beg);
b->store(f);
mtx.unlock(); 

}
FileSpooler::~FileSpooler()
{
    if ( f.is_open()) f.close();
}
