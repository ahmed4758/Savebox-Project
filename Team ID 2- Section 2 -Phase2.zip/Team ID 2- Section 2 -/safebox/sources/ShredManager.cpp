 #include <ShredManager.h>
#include <ThreadManager.h>
#include <MultiHeadQueue.h>
ShredManager::ShredManager () // added this in phase 2
{
}

ShredManager::ShredManager(char * p_file_name, uint16_t p_block_size, uint16_t p_shred_count,bool truncate)
{
    shred_count = p_shred_count;
    shreds = (Shred ** ) calloc (shred_count,sizeof(Shred*));
    for ( char i = 0 ; i  < shred_count; i++)
    {
        string fname = p_file_name;
        fname.insert(fname.find('.'),1,i+'A');
        cout << fname << endl;
        if (truncate)
            shreds[i] = new Shred(fname.c_str(),p_block_size,truncate);
        else shreds[i] = new Shred(fname.c_str(),(p_block_size+16)&~15,truncate);
    }
}
bool ShredManager::encrypt (FileSpooler * fileSpooler, const char * key_file_name, const char * iv_file_name)
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );

    ifstream kf;
    kf.open(key_file_name,ios::in);
    if ( kf.is_open())
    {
        kf.read (reinterpret_cast<char*>(key),sizeof(key));
        kf.close();
    }
    prng.GenerateBlock(iv,sizeof(iv));
    Block * block = fileSpooler->getNextBlock();
    for (int i = 0 ;block != NULL; i ++)
    {
        block->encrypt(key,iv);
        *(shreds[i%shred_count]) << *block;
        delete (block);
        block = fileSpooler->getNextBlock();
    }
    ofstream f;
    f.open(iv_file_name,ios::out|ios::trunc);
    if ( f.is_open())
    {
        f.write (reinterpret_cast<const char*>(iv),sizeof(iv));
        f.close();
    }
    return true;
}
bool ShredManager::decrypt (FileSpooler * fileSpooler, const char * key_file_name, const char * iv_file_name)
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    ifstream f;
    f.open(key_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(key),sizeof(key));
        f.close();
    }

    f.open(iv_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(iv),sizeof(iv));
        f.close();
    }

    Block * block = NULL;
    for (int i = 0 ; i == 0 || block != NULL; i ++)
    {
        block = shreds[i%shred_count]->getNextBlock();
        if ( block == NULL) break;
        block->decrypt(key,iv);
        //block->print();
        fileSpooler->appendBlock(block);
        delete (block);
    }
    return false;
}
ShredManager::~ShredManager()
{
    for ( int i = 0 ; i  < shred_count; i++)
        delete(shreds[i]);
    free(shreds);
}
//*************

MultithreadedShredManager::MultithreadedShredManager(char * p_file_name, uint16_t p_block_size, uint16_t p_shred_count,bool p_truncate) : ShredManager()
{
    file_name = p_file_name;
    shred_count = p_shred_count;
    block_size = p_block_size;
    truncate = p_truncate;
    shreds = (Shred ** ) calloc (shred_count,sizeof(Shred*));
}






bool MultithreadedShredManager::encrypt (FileSpooler * p_fileSpooler, char * key_file_name,  char * iv_file_name, char * q_file_name)
{	//instantiate a queue, a threadmanage, a lottery
	MultiHeadQueue<sb_block_index_t> mtq; 
    	ThreadManager thrm; 
    	Lottery lot(p_fileSpooler->getBlockCount());
    


    AutoSeededRandomPool prng;
//generate key and iv
CryptoPP::byte* iv = new byte[ CryptoPP::AES::BLOCKSIZE ];
    CryptoPP::byte* key = new byte[ CryptoPP::AES::DEFAULT_KEYLENGTH ];
	//CryptoPP::byte* iv = new byte[ CryptoPP::AES::BLOCKSIZE ];
    //memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    prng.GenerateBlock(iv,sizeof(iv));    
	ofstream file;
	file.open(iv_file_name,ios::out);
    if ( file.is_open())
    {
        file.write (reinterpret_cast<const char*>(iv),CryptoPP::AES::BLOCKSIZE);
        file.close();
    }
    //std::cout<<"this is my shred manager" << iv << endl;
	// Loop over shred count and fix the name
	//instantiate an EncryptShredThread for each shred
   for ( char i =0 ; i<shred_count ; i++){ 
       string namef = file_name;

        // string iv_N=iv_file_name;

        namef.insert(namef.find('.'),1,i+'A');
        //iv_N.insert(iv_N.find('.'),1,i+'A');
        char namep = (i+'A');
        if( truncate)
     shreds[i]= new EncryptShredThread(p_fileSpooler,key_file_name,iv_file_name,(char*)(namef.c_str()),block_size/*Be careful*/,&lot,&mtq,namep,truncate);
else      shreds[i]= new EncryptShredThread(p_fileSpooler,(key_file_name),iv_file_name,(char*)(namef.c_str()),(block_size+16)&~15/*Be careful*/,&lot,&mtq,namep,truncate);

thrm += dynamic_cast <Thread *> (shreds[i]);
   }
// satart all tthe threads
thrm.start(); 
thrm.barrier(); 
// save the queue
mtq.dump(q_file_name,key_file_name,iv_file_name);

//multiHeadQueue->dump(q_file_name,key_file_name,iv_N);
    return true;
}






bool MultithreadedShredManager::decrypt (FileSpooler * p_fileSpooler, char * key_file_name,  char * iv_file_name, char * q_file_name)
{
//instantiate from threadmanager and lottery
ThreadManager thrm;

MultiHeadQueue<sb_block_index_t> mtq;
mtq.load(q_file_name,key_file_name,iv_file_name); //loading the queue which entails dexryption
  //  Lottery* lottery = new Lottery(p_fileSpooler->getBlockCount());
//loop over shred count and fix the name
// instantiate from DecryptShredThread to each shred
char c=0; // c for looping over shred count
while(c < shred_count){
    string namef = file_name;
    namef.insert(namef.find('.'),1,c+'A');
    //string iv_N = iv_file_name;
    //iv_N.insert(iv_N.find('.'),1,i+'A');
    char namep = ('A'+c);    
    if ( truncate)
        shreds[c]= new DecryptShredThread(p_fileSpooler,key_file_name,iv_file_name,(char*)namef.c_str(),(block_size),&mtq,namep,truncate) ;
else
    shreds[c]= new DecryptShredThread(p_fileSpooler,key_file_name,iv_file_name,(char*)namef.c_str(),(block_size+16)&~15,&mtq,namep,truncate) ;
//shreds[i]->mainThreadBody();
thrm+= dynamic_cast <Thread *> (shreds[c]);
c++;
}
//run and join all the threads
thrm.start();
thrm.barrier();
    return true;
}

MultithreadedShredManager::~MultithreadedShredManager()
{

} 


/*
ShredManager::ShredManager(char * p_file_name, uint16_t p_block_size, uint16_t p_shred_count,bool truncate)
{
    shred_count = p_shred_count;
    shreds = (Shred ** ) calloc (shred_count,sizeof(Shred*));
    for ( char i = 0 ; i  < shred_count; i++)
    {
        string fname = p_file_name;
        fname.insert(fname.find('.'),1,i+'A');
        cout << fname << endl;
        if (truncate)
            shreds[i] = new Shred(fname.c_str(),p_block_size,truncate);
        else shreds[i] = new Shred(fname.c_str(),(p_block_size+16)&~15,truncate);
    }
}
bool ShredManager::encrypt (FileSpooler * fileSpooler, const char * key_file_name, const char * iv_file_name)
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );

    ifstream kf;

*/
