#include <ThreadManager.h>


ThreadManager::ThreadManager(){

}
void ThreadManager::operator += (Thread * t){
    threads.push_back(t);
}
void ThreadManager::start ()
{
//loop over all threads and start
for ( auto thread = threads.begin() ; thread!=threads.end() ; thread++) 
thread[0]->start();
}
void ThreadManager::barrier (){
//loop over all threads and wait, join()
for ( auto thread= threads.begin() ; thread!=threads.end() ; thread++) 
thread[0]->wait(); 
}
ThreadManager::~ThreadManager(){
}
