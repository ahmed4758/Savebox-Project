#ifndef MULTIHEADQUEUE_H
#define MULTIHEADQUEUE_H

#include <includes.h>
#include <defines.h>
#include <vector>
#include <thread>
#include <fstream>

using namespace std;

template <typename T>
class MultiHeadQueue: private std::vector<T>{
    
    private:
        mutex mtx;
    public:
// creating two methods  for fast encryption and decryption 
void encrypt(CryptoPP::byte * key, CryptoPP::byte * iv, T * buffer, long sz/*size*/)
{
    std::string ciphertext;
    CryptoPP::AES::Encryption aesEncryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Encryption cbcEncryption( aesEncryption, iv );
    CryptoPP::StreamTransformationFilter stfEncryptor(cbcEncryption, new CryptoPP::StringSink( ciphertext ) );
    stfEncryptor.Put( reinterpret_cast<const unsigned char*>( buffer ), sz );
    stfEncryptor.MessageEnd();
    memcpy (buffer,ciphertext.c_str(),ciphertext.size());
    buffer = (T*) buffer;
    //read_size = ciphertext.size();
}
//fix decrypt
void decrypt(CryptoPP::byte * key, CryptoPP::byte * iv, T * buffer, long sz)
{
    std::string decryptedtext;
    CryptoPP::AES::Decryption aesDecryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Decryption cbcDecryption( aesDecryption, iv );
    CryptoPP::StreamTransformationFilter stfDecryptor(cbcDecryption, new CryptoPP::StringSink( decryptedtext ) );
    stfDecryptor.Put( reinterpret_cast<const unsigned char*>( buffer ), sz );
    stfDecryptor.MessageEnd();
    //read_size = (uint16_t) decryptedtext.size();
    memcpy (buffer,decryptedtext.c_str(),sz);
    buffer = (T*) buffer;
}

        MultiHeadQueue ():vector<T>(){
        }
        void enqueue(T & t)
        {
            mtx.lock();
            vector<T>::push_back(t);
            mtx.unlock();
        }
        bool dequeue(T & t,std::function <bool (T&,T&)> check)
        {
/*
The function dequeue uses the lambda function check to check if the provided
sb_block_index_t shred is present in the queue. It then returns the first block found with that shred
name.
*/
            mtx.lock();
            T e;
            for (auto it = vector<T>::begin() ;it != vector<T>::end();it++)
            {//t =x[0];
            if(check(t,it[0])){
            t=it[0];
            //std::cout<<"newoooooooo" <<std::endl;
            vector<T>::erase(it);
            mtx.unlock();
            return false;
            }
}
            mtx.unlock();
            return true;
        }


 void dump (char * filename,char * p_key_file,char * p_iv_file)
        {
/*
In function dump, open the queue, iv, and key files. Read the queue data into a buffer and encrypt it and
write the buffer to its file.
*/
            mtx.lock();
            ofstream f;
            f.open(filename,ios::out);
            T * buffer = (T *) calloc(vector<T>::size(),sizeof(T));
            buffer = vector<T>::data(); 
            long buffer_size = vector<T>::size()*sizeof(T);

            //reading key and IV
            ifstream f1, ivFile;
	        byte *key = new byte[CryptoPP::AES::DEFAULT_KEYLENGTH];
	        byte *iv = new byte[AES::BLOCKSIZE];
            f1.open(p_key_file,ios::in);
	        f1.read(reinterpret_cast<char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);
	        ivFile.open(p_iv_file,ios::in);
	        if (ivFile.is_open())
	            ivFile.read(reinterpret_cast<char*>(iv),AES::BLOCKSIZE); 
            
            //encrypting
            //encrypt(key, iv, buffer, buffer_size);
            //Buffer is encrypted and ready to be dumped 
                if ( f.is_open()){ 
               f.write(reinterpret_cast<char*> (buffer), buffer_size);
            }

            f.close();
            ivFile.close();
            f1.close();
            //if (buffer!=NULL)   free(buffer);
            mtx.unlock();
        }
        void load (char * filename,char * p_key_file,char * p_iv_file)
        {
/*
Load is just the opposite of Dump. Load the iv, key, and queue and then decrypt it.
*/
            //filename has the que encrypted
            mtx.lock();
            ifstream f;
            f.open(filename,ios::in);
            if ( f.is_open())
            {   // decrypt first and then read into the buffer


                //reading queue
                f.seekg(0,f.end);
                long sz = f.tellg();
                f.seekg(0,f.beg);
                T * buffer = (T *) calloc(sz/sizeof(T),sizeof(T)); //buffer has the que encrypted
                f.read (reinterpret_cast<char*>(buffer),sz);
                f.close(); //Do not close the file
                
                //reading key and IV
                ifstream f1, ivFile;
	            byte *key = new byte[CryptoPP::AES::DEFAULT_KEYLENGTH];
	            byte *iv = new byte[AES::BLOCKSIZE];
	            f1.open(p_key_file,ios::in);
	            f1.read(reinterpret_cast<char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);
	            ivFile.open(p_iv_file, ios::in);
	            if (ivFile.is_open())
		            ivFile.read(reinterpret_cast<char*>(iv),AES::BLOCKSIZE);

                
                //decrypting
                //decrypt(key, iv, buffer, sz/*size*/);
                // what might T be?
                
                // You need to add some neccessary code here
                sz/=sizeof(T);
                for ( int i = 0 ; i < sz ; i++)
                    vector<T>::push_back(buffer[i]);
                free (buffer);
                        ivFile.close();
            f1.close();
            mtx.unlock();
            }

        }






        ~MultiHeadQueue(){}
};



#endif
