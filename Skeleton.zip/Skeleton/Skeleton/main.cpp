#include "AVLTree.hpp"

int main ()
{
    AVLTree <int> avlTree;
    srand(time(NULL));
    for ( int i = 0 ; i < 1000000 ; i ++)
        avlTree.insert(rand());
    cout << "Printing "<< endl;
    avlTree.traverseDESC();

	exit(1);
	return 0;
}