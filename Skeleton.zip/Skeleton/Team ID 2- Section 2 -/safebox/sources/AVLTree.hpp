#include "AVLNode.hpp"
/****************************************************************************************/
/*                                 AVLTree Prototype                                    */
/****************************************************************************************/
template <typename ITEM>
class AVLTree : public BinarySearchTree<AVLNode<ITEM>, ITEM>
{
private:
	AVLNode <ITEM> * updateHeightAndEvaluateBalance(AVLNode <ITEM> * n);
	void rotateWithLeftChild(AVLNode <ITEM> * p);
	void rotateWithRightChild(AVLNode <ITEM> * p);
	void doubleRotateWithLeftChild(AVLNode <ITEM> * p);
	void doubleRotateWithRightChild(AVLNode <ITEM> * p);
	int min;
	int max;
public:
	AVLTree();
	AVLNode <ITEM> * insert(const ITEM & item);
	bool remove(const ITEM & item);
	void traverse(AVLNode <ITEM> * n = NULL, int depth = 0);
	void printStats();
	~AVLTree();
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*                               AVLTree Implementation                                 */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

template <typename ITEM>  AVLNode <ITEM> * AVLTree<ITEM>::updateHeightAndEvaluateBalance(AVLNode <ITEM> * n)
{
	if (n == NULL) return NULL;
	n->setHeight(MAX(HEIGHT(n->getLeft()), HEIGHT(n->getRight())) + 1);
	if (!(HEIGHT(n->getLeft()) - HEIGHT(n->getRight()) > 1 || HEIGHT(n->getRight()) - HEIGHT(n->getLeft()) > 1))
		return updateHeightAndEvaluateBalance(n->getParent());
	else return n;
}
template <typename ITEM> void AVLTree<ITEM>::rotateWithLeftChild(AVLNode <ITEM> * p)
{
	AVLNode <ITEM> *n;
	//if (n == NULL) return NULL;
	//n->setHeight(MAX(HEIGHT(n->getLeft()), HEIGHT(n->getRight())) + 1);
	p->setParent(root->getLeft());
	n->setLeft(root->getLeft()->getLeft());
	root->getLeft()->getRight()->setRight(root);
	this->root->setParent(p);
	if (right->getHeight()>left->getHeight())
	p->setHeight(HEIGHT(right)+1)
	else
		p->setHeight(HEIGHT(right)+1)
	//This function need to be written by you.
}

template <typename ITEM> void AVLTree<ITEM>::rotateWithRightChild(AVLNode <ITEM> * p)
{
	AVLNode <ITEM> *n;
	p->setParent(root->getRight());
	n->setRight(root->getRight()->getRight());
	root->getRight()->getLeft()->setLeftt(root);
	this->root->setParent(p);
	if (getRight()->getHeight()>getLeft()->getHeight())
	p->setHeight(HEIGHT(getRight())+1)
	else
		p->setHeight(HEIGHT(getLeft())+1)
	//This function need to be written by you.
}

template <typename ITEM> void AVLTree<ITEM>::doubleRotateWithLeftChild(AVLNode <ITEM> * p)
{
	AVLNode <ITEM> *n;
	root->getLeft()->setRight(n);
	root->getLeft()->setParent(p);
	root->getLeft()->setLeft(n);
	n->getLeft()->setParent(p);
	rotateWithLeftChild(p);
	//This function need to be written by you.
}
template <typename ITEM> void AVLTree<ITEM>::doubleRotateWithRightChild(AVLNode <ITEM> * p)
{
	AVLNode <ITEM> *n;
	root->getRight()->setLeft(n);
	root->getRight()->setParent(p);
	root->getRight()->setRight(n);
	n->getRight()->setParent(p);
	rotateWithLeftChild(p);
	
	//This function need to be written by you.
}

template <typename ITEM> AVLTree<ITEM>::AVLTree() :BinarySearchTree<AVLNode<ITEM>, ITEM>() { min = 1000000; max = 0; }
template <typename ITEM> AVLNode <ITEM> * AVLTree<ITEM>::insert(const ITEM & item) {
	AVLNode <ITEM> * avlNode = BinarySearchTree<AVLNode<ITEM>, ITEM>::insert(item);

	while (avlNode != NULL)
	{
		AVLNode <ITEM> * balance_node = updateHeightAndEvaluateBalance(avlNode);
		if (balance_node != NULL)
		{
			if (balance_node->getLeft() != NULL)
			{
				if (HEIGHT(balance_node->getLeft()->getLeft()) >= HEIGHT(balance_node->getLeft()->getRight()))
					rotateWithLeftChild(balance_node); // Insertion into the left sub tree of the left child
				else doubleRotateWithLeftChild(balance_node);
			}
			if (balance_node->getRight() != NULL)
			{
				if (HEIGHT(balance_node->getRight()->getRight()) >= HEIGHT(balance_node->getRight()->getLeft()))
					rotateWithRightChild(balance_node);  // Insertion into the right sub tree of the right child
				else doubleRotateWithRightChild(balance_node);
			}
		}
		avlNode = balance_node;
	}
	return avlNode;
}
template <typename ITEM> void AVLTree<ITEM>::traverse(AVLNode <ITEM> * n, int depth)
{
	if (n == NULL) n = this->root;
	depth++;
	if (ISLEAF(n))
	{
		if (max < depth) max = depth;
		if (min > depth) min = depth;
		return;
	}
	if (n->getLeft() != NULL) traverse(n->getLeft(), depth);
	if (n->getRight() != NULL) traverse(n->getRight(), depth);
}



template <typename ITEM> void AVLTree<ITEM>::printStats()
{
	cout << "Min:" << min << endl;
	cout << "Max:" << max << endl;

}



template <typename ITEM> bool AVLTree<ITEM>::remove(const ITEM & item) {
	return BinarySearchTree<AVLNode<ITEM>, ITEM>::remove(item);
}
template <typename ITEM> AVLTree<ITEM>::~AVLTree(){}
