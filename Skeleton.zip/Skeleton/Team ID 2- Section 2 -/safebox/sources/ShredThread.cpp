#include <ShredThread.h>

ShredThread::ShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name, const char * p_file_name,uint16_t block_size,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate):Thread(), Shred(p_file_name,block_size,truncate)
{
        srcFileSpooler = p_fileSpooler;
        key_file_name = p_key_file_name;
        iv_file_name = p_iv_file_name;
        multiHeadQueue = p_multiHeadQueue;
        shred_name = p_shred_name;
}
void ShredThread::mainThreadBody(){}
ShredThread::~ShredThread(){}

EncryptShredThread::EncryptShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name,const char * p_file_name,uint16_t block_size,Lottery * p_lottery,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate) : ShredThread(p_fileSpooler, p_key_file_name, p_iv_file_name,p_file_name,block_size,p_multiHeadQueue,p_shred_name,truncate)
{
    lottery = p_lottery;
}
void EncryptShredThread::mainThreadBody()
{
//    AutoSeededRandomPool prng;
    CryptoPP::byte* key = new byte[ CryptoPP::AES::DEFAULT_KEYLENGTH ];
	CryptoPP::byte* iv = new byte[ CryptoPP::AES::BLOCKSIZE ];
    //memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    //memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    
    ifstream kf;
    kf.open(key_file_name,ios::in);
    if ( kf.is_open())
    {
        kf.read (reinterpret_cast<char*>(key), CryptoPP::AES::DEFAULT_KEYLENGTH);
        kf.close();
    }

//    prng.GenerateBlock(iv,sizeof(iv));
// changed ofstream to  ifstream coz we are reading the iv
    ifstream f;
	f.open(iv_file_name.c_str(),ios::out|ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(iv),sizeof(iv));
        f.close();
    }
//create a struct to hold the shred name
sb_block_index_t t;
    t.shred= shred_name;//where this block is in the shred.
//withdraw a ticket
long lott = lottery->withdraw();
int c = 0;					// counter for shred_block
//for ( int j = 0;lott!=-1 ;j++)
while(lott!=-1 )

	{Block* b=(*srcFileSpooler)[lott]; //instantiate a block to hold a block from the FileSpooler at a Lottery randmoized location
	b->encrypt(key,iv);			//encrypt the block
	*(this) << *b;
//delete(block); 
	
	t.shred_block = c;		// occupy the struct 
	t.block= lott;
	multiHeadQueue->enqueue(t);	// save the struct
	
	lott = lottery->withdraw();
	c++;
	delete(b); 				
}
std::cout<<key<<std::endl;
std::cout<<"my iv is " << iv<<std::endl;
}
EncryptShredThread::~EncryptShredThread()
{

}

DecryptShredThread::DecryptShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name,const char * p_file_name,uint16_t block_size,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate): ShredThread(p_fileSpooler, p_key_file_name, p_iv_file_name,p_file_name,block_size,p_multiHeadQueue,p_shred_name,truncate)
{
    

}
Block * DecryptShredThread::operator [] (int index)
{
    return (*fileSpooler)[index];
}

void DecryptShredThread::mainThreadBody()
{
    AutoSeededRandomPool prng;
    CryptoPP::byte* key = new byte[ CryptoPP::AES::DEFAULT_KEYLENGTH ];
	CryptoPP::byte* iv = new byte[ CryptoPP::AES::BLOCKSIZE ];
    //memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    //memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    ifstream f;
    f.open(key_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);
        f.close();
    }
    f.open(iv_file_name.c_str(),ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(iv),CryptoPP::AES::BLOCKSIZE);
        f.close();
    }
     
//create a struct to hold shred name
sb_block_index_t t;
t.shred=shred_name;
//loop while there are elements in mthqueue
while( multiHeadQueue ){

//Block *b = new Block(/*block_size*/);
//dequeue 
if(multiHeadQueue->dequeue(t,[](sb_block_index_t &t1, sb_block_index_t &t2)->bool{
    if(t1.shred == t2.shred) return true; 
    else return false;
})){/*std::cout << "meaooooo" << std::endl;*/ break;}
//create a block to save the block in the shred in the corresponding location
Block* b=(*this)[t.shred_block];//b->load(s);
//decrypt and then write at t.block location
b->decrypt(key,iv);
srcFileSpooler->writeBlockAt(b,t.block);

}

}
DecryptShredThread::~DecryptShredThread()
{
    
}
