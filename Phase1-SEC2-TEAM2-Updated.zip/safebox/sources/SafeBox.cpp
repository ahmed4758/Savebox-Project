#include <SafeBox.h>

SafeBox::SafeBox()
{
}
SafeBox::~SafeBox()
{
}
SafeBoxImport::SafeBoxImport()
{
}
void SafeBoxImport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                            uint16_t shreds)
{
    printf("Import file\n");
      char ivs[1024];
      memset(ivs,0,1024);
     strcat(working_dir,"/");
    strcpy(ivs, working_dir);
    strcat(ivs,"iv.txt");
    strcat(working_dir,output_file);

    ShredManager *sh = new ShredManager(working_dir,block_size, shreds, true);

    FileSpooler *fl =new FileSpooler(input_file, block_size, false);
    sh->encrypt(fl,key_file,ivs);
    
}
SafeBox *SafeBoxImport::clone()
{
    return new SafeBoxImport();
}
SafeBoxImport::~SafeBoxImport()
{
}

SafeBoxExport::SafeBoxExport()
{
}
void SafeBoxExport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                           uint16_t shreds)
{
    printf("Export file\n");
      char ivs[1024];
      memset(ivs,0,1024);
    strcat(working_dir,"/");
    strcpy(ivs,working_dir);
    strcat(ivs,"iv.txt");
    strcat(working_dir,input_file);
    ShredManager *sh = new ShredManager(working_dir,block_size, shreds, false);
    FileSpooler *fl =new FileSpooler(output_file, block_size, true);
  
    sh->decrypt(fl,key_file,ivs);
    }
SafeBox *SafeBoxExport::clone()
{
    return new SafeBoxExport();
}
SafeBoxExport::~SafeBoxExport()
{
}
