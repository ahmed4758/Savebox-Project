#include "ShredManager.h"


ShredManager::ShredManager(char *p_file_name, uint16_t p_block_size, uint16_t p_shred_count, bool truncate) // every shredmanager will have a number of shreds stored in **shreds
{ // make array of string foor file names/////////////////// a shred_manager will get an original file and create 10 files/// I think I should instantiate an original shred for the original file

    shred_count = p_shred_count;
    shreds = (Shred **)calloc(shred_count, sizeof(Shred *));
    char c= 'A';
    for (int i = 0; i < shred_count; i++) 
    {  
        string name = p_file_name;      // p_file_name should not have the file extension
        name = name.insert(name.length(),"_");
        string s (1, c); // make string from charecter
        name = name.insert(name.length(), s);
        name = name.insert(name.length(), ".txt");
        if (truncate){
        	shreds[i] = new Shred(name.c_str(), p_block_size, truncate); 
        	c++;

        }else {
        shreds[i] = new Shred(name.c_str(), ((p_block_size+16)&~15), truncate); // 10 shreds are stored in **shreds 
        }
        // incrementing the charecter
        //cout << name << endl; /**/
        
    }
}



bool ShredManager::encrypt(FileSpooler *fileSpooler , const char *key_file_name, const char *iv_file_name) // here we pass the filespooler contained in the shred
{

   ifstream f1;
	byte key[CryptoPP::AES::DEFAULT_KEYLENGTH];
        byte iv[AES::BLOCKSIZE];
	f1.open(key_file_name,ios::in);
	f1.read(reinterpret_cast<char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);
	ofstream ivFile;
	ivFile.open(iv_file_name,ios::in|ios::trunc);
	AutoSeededRandomPool rnd;
    rnd.GenerateBlock(iv, sizeof(iv));
    //cout << fileSpooler<< endl; 
    Block *b=fileSpooler->getNextBlock();
int x=0;
	while ( b!= NULL){
		b->encrypt(key,iv);
		*(shreds[x%shred_count])<<*(b);
		b=fileSpooler->getNextBlock();
        x++;
	}
	ivFile.write(reinterpret_cast<char*>(iv),sizeof(iv));// write the ivs

	f1.close();
	ivFile.close();
	return true;
   }
bool ShredManager::decrypt(FileSpooler *fileSpooler, const char *key_file_name, const char *iv_file_name)
{

	ifstream f1, ivFile;
	byte key[CryptoPP::AES::DEFAULT_KEYLENGTH];
	byte iv[AES::BLOCKSIZE];
	f1.open(key_file_name,std::ios::in);
	f1.read(reinterpret_cast<char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);
	ivFile.open(iv_file_name,std::ios::in);
	if (ivFile.is_open())
		ivFile.read(reinterpret_cast<char*>(iv),AES::BLOCKSIZE);
	Block *b;
    int a = 0; 
	while (true){
        b=shreds[0]->getNextBlock();
                 if ( b==NULL) break; 

		b->decrypt(key,iv);
		fileSpooler->appendBlock(b);
		delete(b);
         a++; 
	}
	f1.close();
	ivFile.close();
	return false;

   /* string key_str, iv_str; // to retrieve the key and iv from the file
    fstream f1(key_file_name), f2(iv_file_name);
    if (f1.is_open() && f2.is_open() ){
        
        getline(f1, key_str);
        getline(f2, iv_str);
    }
    
    byte key[key_str.length()], iv[iv_str.length()];
    
    memcpy(key, key_str.data(), key_str.length());
    memcpy(iv, iv_str.data(), iv_str.length()); 
// getting shred size to determin the number of blocks
    long fsize = shreds[0]->get_shred_size();
    int block_nums = fsize / block_size;
    for (int i = 0; i< block_nums ; i++)  
        
        for (int j = 0; j <shred_count; j++){ // j<3 the number of blocks / shred
            Block *b = shreds[j] ->getNextBlock(); //astrics infront of shreds??
            b -> decrypt(key, iv); // key and iv are defined in the function
            fileSpooler->appendBlock(b); //storing the dencrypted block in its allocated file
        }    
    
    // now iv and key are ready to be passed to Block::decrypt(*key, *iv)
    return false; /* why is it set to false?? */
}
ShredManager::~ShredManager()
{
    for (int i = 0; i < shred_count; i++)
        delete (shreds[i]);
    free(shreds);
}




/*

//test
int main(){
FileSpooler *fileSpooler = new FileSpooler ("test2.txt", 110);
//FileSpooler *fileSpooler = new FileSpooler ("decrypted.txt", 1);
ShredManager shredmanager("test", 1, 10, false);
shredmanager.encrypt(fileSpooler, "key.txt","iv.txt");
//shredmanager.decrypt(fileSpooler, "key.txt","iv.txt");
return 0;
}
*/




