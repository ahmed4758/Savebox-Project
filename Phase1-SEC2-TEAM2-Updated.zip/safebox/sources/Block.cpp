#include "Block.h"
using namespace CryptoPP;
Block::Block(uint32_t p_block_size)
{
    block_size = p_block_size;
    read_size = 0;
    buffer = (char *)calloc(block_size + 1 + (block_size - (block_size % CryptoPP::AES::BLOCKSIZE)), sizeof(char));
}
bool Block::load(std::fstream &f)
{ 
    if (f.is_open())
    {         
        f.read(buffer, block_size);
        read_size = f.gcount(); 
        if (f || f.gcount() > 0)
            return true;
        else
            return false;
    }
    else
        return false;
}
bool Block::store(std::fstream &f)
{
    if (f.is_open())
    {
        f.write(buffer, read_size);
        return true;
    }
    else
        return false;
}
void Block::encrypt(byte *key, byte *iv) // we are passing a pointer
{
    // try 1) use buffer as is 2) convert buffer to string
   std::string ciphertext;
    CryptoPP::AES::Encryption aesEncryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Encryption cbcEncryption( aesEncryption, iv );
    CryptoPP::StreamTransformationFilter stfEncryptor(cbcEncryption, new CryptoPP::StringSink( ciphertext ) );
    stfEncryptor.Put( reinterpret_cast<const unsigned char*>( buffer ), block_size);
    stfEncryptor.MessageEnd();
    read_size = (uint16_t) ciphertext.size();


    memcpy(buffer,ciphertext.c_str(),read_size);

}
void Block::decrypt(byte *key, byte *iv)
{ 

	std::string decrypted_text;
    CryptoPP::AES::Decryption aesDecryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Decryption cbcDecryption( aesDecryption, iv );
    CryptoPP::StreamTransformationFilter stfDecryptor(cbcDecryption, new CryptoPP::StringSink( decrypted_text ) );
    stfDecryptor.Put( reinterpret_cast<const unsigned char*>(buffer),read_size);
    stfDecryptor.MessageEnd();
    memcpy(buffer,decrypted_text.c_str(),decrypted_text.size());
    read_size= (uint16_t) decrypted_text.size();

}
    

void Block::print()
{
    cout << buffer;
}
Block::~Block()
{
    if (buffer != NULL)
        free(buffer);
}

/*
int main(){

string key_str; // to store the key from the file
    fstream f1("key.txt");
    if (f1.is_open()){
        
        getline(f1, key_str);
    }
    cout << "key_str " << key_str << endl;
    byte key[key_str.length()];
    
    memcpy(key, key_str.data(), key_str.length());


  
    byte iv[ CryptoPP::AES::BLOCKSIZE ]; 
    
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    //cout << "key " << key << endl;

Block block(100);
fstream f("test2.txt");
block.load(f);
block.print();

block.encrypt(key, iv);
cout << endl;
block.print();
block.decrypt(key, iv);
return 0;
}

*/

/*int main(){
    //byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ] = {"AAAAAAAAAAAAAAAA"};//{'A', 'A','A', 'A','A', 'A','A', 'A','A', 'A','A', 'A','A', 'A','A', 'A'};
 byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ],  iv[ CryptoPP::AES::BLOCKSIZE ]; 
    string secret = "AAAAAAAAAAAAAAAA";
    memcpy(key, secret.data(), secret.length()); //copying a string into a array of bytes
    //memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    //memset( key, 'A', CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    cout << "key " << key << endl;

Block block(100);
fstream f("test2.txt");
block.load(f);
block.print();

block.encrypt(key, iv);
cout << endl;
block.print();
block.decrypt(key, iv);
return 0;
}
*/



