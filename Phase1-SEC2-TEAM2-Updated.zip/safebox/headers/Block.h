#ifndef BLOCK_H
#define BLOCK_H

#include "defines.h"
#include "includes.h"
//#include <iostream>
#include <fstream>

#include <iostream>
#include <iomanip>

#include "cryptopp/modes.h"
#include "cryptopp/aes.h"
#include "cryptopp/filters.h"
using namespace std;

using namespace std;

class Block {

    private:
        uint32_t block_size; 
        uint32_t read_size;
        char * buffer;
        //my variables

        //int counter = 0;
    public:
        Block (uint32_t p_block_size);
        bool load(fstream & f); // to the buffer
        bool store(fstream & f); // from buffer the file 
        void encrypt(byte * key, byte * iv); // search for them in cryptoPP
        void decrypt(byte * key, byte * iv);
        void print ();
        ~Block();
};
#endif
